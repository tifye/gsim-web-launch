      
from System.IO import File

def SetRawAttributeFromFile(attribute, path):
    data = File.ReadAllBytes(path)
    res = tifDevice.SetRawAttribute(attribute, data, silent = True)

    if res.Success:
        tifConsole.Log(path + ' was applied successfully')
    else:
        tifConsole.Error('Could not apply ' + path)